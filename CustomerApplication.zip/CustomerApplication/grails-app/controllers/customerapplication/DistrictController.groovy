package customerapplication

class DistrictController {
    def create(){
        def stateList=State.list()
        [stateList:stateList]
    }
    def operation()
    {
    }
    def save() { 
        def districtName=params.district
        def stateId=params.stateList
        def id=Integer.parseInt(stateId)
        def stateIns=State.get(id)
        def districtIns=new District()
        districtIns.district=districtName
        districtIns.state=stateIns
        if(districtIns.validate()){
            districtIns.save(flush:true,failOnError:true)
            render view:"operation"
        }
        else{
            flash.message="Please check all the fields"
//             def stateList=State.list()
//             render(view:"create",model:[stateList:stateList])
             redirect action:"create" 
        }
    }
    def display()
    {
        def districtList=District.list()
        [temp:districtList]
    }
    def delete()
    {
        def districtList=District.list()
        [districtList:districtList]
    }
    def deleteAction()
    {
        def district=params.district
        def districtInst=District.get(district)
        districtInst.delete(flush:true)
        render view:"operation"
    }
    def update()
    {
        def districtList=District.list()
        [districtList:districtList]
    }
    def updateAction()
    {
        def id1=params.oldDistrict
        def id=Integer.parseInt(id1)
        def districtOld=District.get(id)
        def districtNew=params.newDistrict
        districtOld.district=districtNew
//        State.executeUpdate("update District d set d.district='"+districtNew+"' where d.id='"+id+"'")
        render view:"operation"
    }
}

