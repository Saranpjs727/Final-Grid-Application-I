package customerapplication

class Customer {

    static constraints = {
        userName      nullable: false,blank: false
        dateOfBirth   nullable: true,blank: false
        email         nullable: false,blank: false,email:true
        password      nullable: false,blank: false
    }
    static belongsTo=[address:Address]
    String userName
    Date dateOfBirth
    String email
    String password
}
