package customerapplication
//import java.lang.*;
import org.apache.poi.hssf.usermodel.HSSFWorkbook
import org.apache.poi.ss.usermodel.Workbook
import org.apache.poi.ss.usermodel.Sheet
import com.google.common.collect.ArrayTable.Row
import org.h2.result.Row
import javax.swing.DefaultRowSorter.Row
import org.hsqldb.Row
import com.sun.rowset.internal.Row
import javax.swing.text.ParagraphView.Row
import com.google.common.collect.StandardTable.Row
import org.apache.poi.ss.usermodel.Row
import com.google.common.collect.Table.Cell
import org.apache.poi.ss.usermodel.Cell
import org.apache.poi.hssf.usermodel.HSSFSheet
import org.apache.poi.hssf.usermodel.HSSFCell
import org.springframework.web.multipart.MultipartFile
import org.springframework.web.multipart.MultipartHttpServletRequest
class CountryController {

    def create() { 
       
    }
    def operation()
    {
    }
    def multipart(){}
    def save()
    {
        def countryInst=new Country(params)
        if(countryInst.validate()){
            countryInst.save(flush:true,failOnError:true)
            render view:"operation"
        }
        else{
            flash.error="Please check all the fields"
            render view:"create"
        }
       
    }
    def display()
    {
        def countryList=Country.list()
        [temp:countryList]
    }
    def delete()
    {
        def countryList=Country.list()
        [countryList:countryList]
    }
    def deleteAction()
    {
        def country=params.country
        def countryInst=Country.get(country)
        countryInst.delete(flush:true)
        render view:"operation"
    }
    def update()
    {
        def countryList=Country.list()
        [countryList:countryList]
    }
    def updateAction()
    {
        def id1=params.oldCountry
        def id=Integer.parseInt(id1)
        // int id= country as Integer
        def countryOld=Country.get(id)
        def countryNew=params.newCountry
         countryOld.country=countryNew
        redirect action:"operation"
    }
    def imports={
         FileInputStream out=new FileInputStream("imports.xls")
         Workbook book = new HSSFWorkbook(out)
         HSSFSheet sheet = book.getSheetAt(0)
                sheet.each { row ->
                    new Country (country:row.getCell((short)0).getStringCellValue(),continent:row.getCell((short)1).getStringCellValue()).save()
        }
    }
    def multiImport(){
      
         if (request instanceof MultipartHttpServletRequest) {
         MultipartFile uploadedFile = ((MultipartHttpServletRequest) request).getFile('update_file')
         InputStream inputStream = new ByteArrayInputStream(uploadedFile?.getBytes())
         Workbook book = new HSSFWorkbook(inputStream)
         HSSFSheet sheet = book.getSheetAt(0)       
                sheet.each { row ->
                new Country (country:row.getCell((short)0).getStringCellValue(),continent:row.getCell((short)1).getStringCellValue()).save()    
    }
   }
  }

}
    


