package customerapplication

import java.text.SimpleDateFormat
// java.text.SimpleDateFormat
import org.apache.poi.hssf.usermodel.HSSFWorkbook
import org.apache.poi.ss.usermodel.Workbook
import org.apache.poi.ss.usermodel.Sheet
import com.google.common.collect.ArrayTable.Row
import org.h2.result.Row
import javax.swing.DefaultRowSorter.Row
import org.hsqldb.Row
import com.sun.rowset.internal.Row
import javax.swing.text.ParagraphView.Row
import com.google.common.collect.StandardTable.Row
import org.apache.poi.ss.usermodel.Row
import com.google.common.collect.Table.Cell
import org.apache.poi.ss.usermodel.Cell
//import com.lowagie.text.Cell
class CustomerController {
    def create(){
        def addressList=Address.list()
        model:[addressList:addressList]
    }
    def operation()
    {}
    def save() { 
        def doorNo=params.doorNo
        def addressIns=Address.get(doorNo)
        def customerIns=new Customer()
        customerIns.userName=params.userName
        customerIns.dateOfBirth=params.dateOfBirth
        customerIns.email=params.email
        customerIns.address=addressIns
        customerIns.password=params.password
        if(customerIns.validate()){
            customerIns.save(flush:true,failOnError:true)
            render view:"operation"
        }
        else{
            flash.message="Please check all the fields"
            //            def addressList=Address.list()
            //            render(view:"create",model:[addressList:addressList])
            redirect action:"create"
        }
    }
    def display()
    {
        params.max = Math.min(params?.max ? params?.int('max') : 5,10)
        def customerList=Customer.list(params)
        [temp:customerList,customerCount: Customer.count()]
    }
    def delete()
    {
        def customerList=Customer.list()
        [customerList:customerList ]
    }
    def deleteAction()
    {
        def email=params.email
        def customerInst=Customer.get(email)
        customerInst.delete(flush:true)
        render view:"operation"
    }
    def update()
    {
        def customerList=Customer.list()
        [customerList:customerList]
    }
    def updateAction()
    {
        def oldName=params.oldName
        def id=Integer.parseInt(oldName)
        def customer=Customer.get(id)
        def newNameIns=params.newName
        customer.userName=newNameIns
        // Customer.executeUpdate("update Customer cs set cs.userName='"+newNameIns+"' where cs.id='"+id+"'")
        render view:"operation"
    }
    def search()
    {}
    def searchAction()
    {
        def field=params.search
        def customer=Customer.createCriteria()
        if(field.equals("dateOfBirth"))
        {
            //            def oldDate=params.date
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd")
            Date date =sdf.parse(params.date_day+"-"+params.date_month+"-"+params.date_year);
            println("date ${date}")
            def result=customer.list{like(field,date) }
            render(view:"display",model:[temp:result,customerCount:Customer.count()])
        }
        else
        {
            def value=params.data
            def result=customer.list{like(field,value)}
            render(view:"display",model:[temp:result,customerCount:Customer.count()])
        }
    }
    def export={
        FileOutputStream out=new FileOutputStream("c:\\extest.xls")
        Workbook wb=new HSSFWorkbook()
        Sheet sheet=wb.createSheet()
        Row row=sheet.createRow(0);
        
            row.createCell((short)0).setCellValue("UserName")
            row.createCell((short)1).setCellValue("DateOfBirth")
            row.createCell((short)2).setCellValue("Email")
            row.createCell((short)3).setCellValue("Password")
        int rownum=1;
        def customerList=Customer.list()
        for(Customer ref: customerList)
        {
            row=sheet.createRow(rownum++)
            row.createCell((short)0).setCellValue(ref.userName)
            row.createCell((short)1).setCellValue(ref.dateOfBirth)
            row.createCell((short)2).setCellValue(ref.email) 
            row.createCell((short)3).setCellValue(ref.password) 
        }
      wb.write(out)
      out.close()
    }

    
}
