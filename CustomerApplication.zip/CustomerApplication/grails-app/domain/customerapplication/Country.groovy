package customerapplication

class Country {

    static constraints = {
        country   nullable: false,blank: false
        continent nullable: false,blank: false 
        
    }
    static hasMany=[state:State]
    String country
    String continent
  
  
}
