package customerapplication

class Address {

    static constraints = {
        doorNo  nullable: false,blank: false
        street  nullable: false,blank: false
        area    nullable: false,blank: false
        pincode  nullable: false,blank: false
    }
    static belongsTo=[district:District]
    static hasMany=[customer:Customer]
    String doorNo
    String street
    String area
    String pincode
}

